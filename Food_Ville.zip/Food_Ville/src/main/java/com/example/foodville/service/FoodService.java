package com.example.foodville.service;

import java.util.List;

import com.example.foodville.entity.Food;


public interface FoodService {
	
	public List<Food> findAll();
	
	public Food findById(int theId);
	
	public void save(Food theMedicine);
	
	public void deleteById(int theId);

}
