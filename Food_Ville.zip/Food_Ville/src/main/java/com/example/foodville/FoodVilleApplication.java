package com.example.foodville;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodVilleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodVilleApplication.class, args);
	}

}
