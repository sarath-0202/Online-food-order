package com.example.foodville.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.example.foodville.entity.User;
import com.example.foodville.rest.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	
	User save(UserRegistrationDto registrationDto);
	}


