package com.example.foodville.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="food")
public class Food {
	
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private int foodId;
	
	private String foodName;
	
	private double foodPrice;
	
	private String foodCategory;
	
	private String foodResturant;
	
	private  int foodQuantity;
	
	private String manufactureDate;
	
	private String expiraryDate;

	public Food(int foodId, String foodName, double foodPrice, String foodCategory, String foodResturant,
			int foodQuantity, String manufactureDate, String expiraryDate) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
		this.foodPrice = foodPrice;
		this.foodCategory = foodCategory;
		this.foodResturant = foodResturant;
		this.foodQuantity = foodQuantity;
		this.manufactureDate = manufactureDate;
		this.expiraryDate = expiraryDate;
	}
	

	public Food() {
		// TODO Auto-generated constructor stub
	}


	public int getFoodId() {
		return foodId;
	}

	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public double getFoodPrice() {
		return foodPrice;
	}

	public void setFoodPrice(double foodPrice) {
		this.foodPrice = foodPrice;
	}

	public String getFoodCategory() {
		return foodCategory;
	}

	public void setFoodCategory(String foodCategory) {
		this.foodCategory = foodCategory;
	}

	public String getFoodResturant() {
		return foodResturant;
	}

	public void setFoodResturant(String foodResturant) {
		this.foodResturant = foodResturant;
	}

	public int getFoodQuantity() {
		return foodQuantity;
	}

	public void setFoodQuantity(int foodQuantity) {
		this.foodQuantity = foodQuantity;
	}

	public String getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(String manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public String getExpiraryDate() {
		return expiraryDate;
	}

	public void setExpiraryDate(String expiraryDate) {
		this.expiraryDate = expiraryDate;
	}

	@Override
	public String toString() {
		return "Food [foodId=" + foodId + ", foodName=" + foodName + ", foodPrice=" + foodPrice + ", foodCategory="
				+ foodCategory + ", foodResturant=" + foodResturant + ", foodQuantity=" + foodQuantity
				+ ", manufactureDate=" + manufactureDate + ", expiraryDate=" + expiraryDate + "]";
	}
	
}
	
	


