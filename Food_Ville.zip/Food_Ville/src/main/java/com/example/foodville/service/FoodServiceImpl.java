package com.example.foodville.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.foodville.dao.FoodRepository;
import com.example.foodville.entity.Food;

@Service
public class FoodServiceImpl implements FoodService {
	
	private FoodRepository foodRepository;
	
	public FoodServiceImpl(FoodRepository theMedicineRepository) {
		foodRepository = theMedicineRepository;
	}

	@Override
	public List<Food> findAll() {
		return foodRepository.findAll();
	}

	@Override
	public Food findById(int theId) {
		Optional<Food> result = foodRepository.findById(theId);
		
		Food theMedicine = null;
		
		if(result.isPresent())
		{
			theMedicine = result.get();
		}
		else
		{
			//we didn't find the medicines
			throw new RuntimeException("Did not find Medicine id- "+theId);
		}
		return theMedicine;
		

	}

	@Override
	public void save(Food theMedicine) {
		foodRepository.save(theMedicine);
		
	}

	@Override
	public void deleteById(int theId) {
		foodRepository.deleteById(theId);
		
	}
	
	
	
	
	
}
